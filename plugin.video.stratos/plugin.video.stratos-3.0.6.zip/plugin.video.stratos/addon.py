# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

GENRES = [
    ("Action", "action"), ("Animation", "animation"), ("Arts Martiaux", "arts-martiaux"),
    ("Aventure", "aventure"), ("Biopic", "biopic"), ("Comédie", "comedie"),
    ("Comédie Dramatique", "comedie-dramatique"), ("Epouvante Horreur", "epouvante-horreur"),
    ("Drame", "drame"), ("Documentaire", "documentaire"), ("Espionnage", "espionnage"),
    ("Famille", "famille"), ("Fantastique", "fantastique"), ("Guerre", "guerre"),
    ("Historique", "historique"), ("Musical", "musical"), ("Policier", "policier"),
    ("Romance", "romance"), ("Science Fiction", "science-fiction"), ("Spectacles", "spectacles"),
    ("Thriller", "thriller"), ("Western", "western")
]

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

def add_item(name, action, url, thumb="", is_folder=True, plot="", title_orig="", mode_type="", post_data=None):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    info = li.getVideoInfoTag()
    if plot: info.setPlot(plot)
    info.setTitle(title_orig or name)
    info.setMediaType('movie')
    
    params = {'action': action, 'url': url, 'title': title_orig, 'mode_type': mode_type}
    if post_data: params['post_data'] = urllib.parse.urlencode(post_data)
    
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- FONCTION RECHERCHE ---
def search_movie():
    search_query = xbmcgui.Dialog().input("Rechercher un film ou une série...", type=xbmcgui.INPUT_ALPHANUM)
    if search_query:
        # Données POST basées sur le formulaire du site
        search_url = f"{BASE_URL}/index.php?do=search"
        post_data = {
            'do': 'search',
            'subaction': 'search',
            'search_start': '0',
            'full_search': '0',
            'result_from': '1',
            'story': search_query
        }
        # On appelle list_movies avec les données POST
        list_movies(search_url, post_data=post_data)

# --- FONCTION ALLER À LA PAGE ---
def go_to_page(url):
    kb = xbmcgui.Dialog().numeric(0, "Aller à la page :")
    if kb:
        page_num = str(kb)
        base_url_clean = re.sub(r'/page/\d+/', '/', url)
        if base_url_clean.endswith('/'): base_url_clean = base_url_clean[:-1]
        
        if '?' in base_url_clean:
            new_url = base_url_clean.replace('?', f'/page/{page_num}/?')
        else:
            new_url = f"{base_url_clean}/page/{page_num}/"
        list_movies(new_url)

# --- MENUS ---
def genres_menu(mode_type):
    path_base = "film" if mode_type == "movies" else "serie"
    
    # Bouton Recherche en haut de chaque sous-menu
    add_item("[COLOR lightgreen]🔍 RECHERCHER[/COLOR]", "search", "")
    
    # Catégories Spéciales
    add_item("[COLOR yellow]⭐ LES PLUS POPULAIRES[/COLOR]", "list_movies", f"{BASE_URL}/{path_base}-en-streaming/page/1/?filter_by=views", mode_type=mode_type)
    add_item("[COLOR orange]📅 LES ANCIENS (RÉTRO)[/COLOR]", "list_movies", f"{BASE_URL}/film-ancien/", mode_type=mode_type)
    
    add_item("-------------------------------------------", "", "") 
    
    for name, slug in GENRES:
        url = f"{BASE_URL}/{path_base}-en-streaming/{slug}/"
        add_item(name, "list_movies", url, mode_type=mode_type)
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(url, mode_type="movies", post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    
    # Barre de navigation
    add_item("[COLOR red]⬅ RETOUR AU MENU[/COLOR]", "main", "")
    add_item("[COLOR lightblue]🔢 ALLER À LA PAGE...[/COLOR]", "go_to_page", url)

    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        if post_data:
            r = requests.post(url, headers=headers, data=post_data, timeout=10)
        else:
            r = requests.get(url, headers=headers, timeout=10)
            
        soup = BeautifulSoup(r.text, 'html.parser')
        
        items = soup.find_all('div', class_='mov')
        for item in items:
            link_tag = item.find('a', class_='mov-t')
            if not link_tag: continue
            m_url = link_tag['href']
            m_title = link_tag.get_text(strip=True)
            img_tag = item.find('img')
            m_thumb = (BASE_URL + img_tag['src']) if img_tag and img_tag['src'].startswith('/') else img_tag.get('src', '') if img_tag else ""
            desc_divs = item.find_all('div', class_='ml-desc')
            m_plot = desc_divs[-1].get_text(strip=True) if desc_divs else ""

            add_item(m_title, 'select_source', m_url, thumb=m_thumb, plot=m_plot, title_orig=m_title)

        # PAGINATION CALCULÉE (Uniquement si ce n'est pas une recherche POST simple)
        if items and not post_data:
            match = re.search(r'/page/(\d+)', url)
            if match:
                curr = int(match.group(1))
                n_url = url.replace(f'/page/{curr}', f'/page/{curr+1}')
            else:
                n_url = url.replace('?', 'page/2/?') if '?' in url else url.rstrip('/') + "/page/2/"
            
            add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", n_url, thumb=get_art("next.png"))

    except Exception as e:
        xbmc.log(f"FLEMMIX ERROR: {str(e)}", xbmc.LOGERROR)
        
    xbmcplugin.endOfDirectory(HANDLE)

# --- SOURCES ET LECTURE (Identique) ---
def select_source(url):
    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        matches = re.findall(r"loadVideo\('([^']+)'\).*?<span>([^<]+)</span>", r, re.S)
        for v_url, srv_name in matches:
            if v_url.startswith('//'): v_url = "https:" + v_url
            li = xbmcgui.ListItem(label=f"▶ {srv_name.strip().upper()}")
            li.setProperty('IsPlayable', 'true')
            q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
        xbmcplugin.endOfDirectory(HANDLE)
    except: xbmcplugin.endOfDirectory(HANDLE, False)

def play_video(url):
    try:
        import resolveurl
        resolved = resolveurl.resolve(url)
        if resolved: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=resolved))
    except: pass

# --- ROUTER ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    m_type = params.get('mode_type', 'movies')
    
    # Gestion des données POST passées entre les pages
    p_data = urllib.parse.parse_qs(params.get('post_data', '')) if params.get('post_data') else None

    if not action or action == 'main':
        add_item("🎬 FILMS", "genres_menu", "", mode_type="movies")
        add_item("📺 SÉRIES", "genres_menu", "", mode_type="series")
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == 'genres_menu':
        genres_menu(m_type)
    elif action == 'search':
        search_movie()
    elif action == 'list_movies':
        list_movies(params.get('url'), mode_type=m_type, post_data=p_data)
    elif action == 'go_to_page':
        go_to_page(params.get('url'))
    elif action == 'select_source':
        select_source(params.get('url'))
    elif action == 'play':
        play_video(params.get('url'))
