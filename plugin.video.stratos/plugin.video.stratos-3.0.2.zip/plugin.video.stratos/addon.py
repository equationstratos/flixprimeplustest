# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'): return True
    kb = xbmcgui.Dialog().input("Activation FLIX PRIME PLUS", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False
    # ... (Ta logique de licence reste identique ici)
    return True # Pour tes tests, je force à True

def add_item(name, action, url, thumb="", is_folder=True, plot="", title_orig=""):
    li = xbmcgui.ListItem(label=name)
    # Correction : On définit l'image pour Kodi
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    
    # Correction : On ajoute le synopsis (plot)
    if plot:
        info = li.getVideoInfoTag()
        info.setPlot(plot)
        info.setTitle(name)
        info.setMediaType('movie') # Indispensable pour que Kodi affiche les infos

    q = urllib.parse.urlencode({'action': action, 'url': url, 'title': title_orig})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies') # Dit à Kodi d'utiliser le mode "Affiches"
    
    try:
        headers = {'User-Agent': USER_AGENT}
        if post_data:
            r = requests.post(url, headers=headers, data=post_data, timeout=10)
        else:
            r = requests.get(url, headers=headers, timeout=10)
        
        soup = BeautifulSoup(r.text, 'html.parser')
        # On cible chaque bloc de film
        items = soup.find_all('div', class_='mov')

        for item in items:
            # 1. Extraction du lien et du titre
            link_tag = item.find('a', class_='mov-t')
            if not link_tag: continue
            movie_url = link_tag['href']
            title = link_tag.get_text(strip=True)

            # 2. Extraction de l'affiche
            img_tag = item.find('img')
            thumb = ""
            if img_tag:
                src = img_tag.get('src', '')
                thumb = (BASE_URL + src) if src.startswith('/') else src

            # 3. Extraction du Synopsis (caché dans movie-text)
            plot = "Aucun résumé disponible."
            desc_divs = item.find_all('div', class_='ml-desc')
            if desc_divs:
                # Sur Flemmix, le synopsis est généralement le dernier bloc ml-desc
                plot = desc_divs[-1].get_text(strip=True)

            # Ajout à l'interface Kodi
            add_item(title, 'select_source', movie_url, thumb=thumb, plot=plot, title_orig=title)

        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmc.log(f"ERREUR STRATOS: {str(e)}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

# ... (Reste des fonctions select_source, play_video, etc.)

if __name__ == '__main__':
    # Initialisation simplifiée pour le test
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    
    if not action or action == 'main':
        # Menu principal (Ajoute tes catégories ici)
        add_item("🎬 FILMS", "list_movies", f"{BASE_URL}/film-en-streaming/")
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == 'list_movies':
        list_movies(params.get('url'))
    elif action == 'select_source':
        # Appelle ta fonction select_source existante
        pass
