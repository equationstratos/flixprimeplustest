# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from bs4 import BeautifulSoup
from datetime import datetime

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
LICENSE_SERVER_URL = "https://ton-serveur.com/licence.php" # À MODIFIER
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

# --- Système de Protection ---
def get_uuid():
    return xbmc.getCleanDeviceId()

def check_license():
    uuid = get_uuid()
    # On utilise tes IDs de settings.xml
    stored_hash = ADDON.getSetting('stratflix_license_hash')
    
    if not stored_hash:
        # Première activation
        code = xbmcgui.Dialog().input("Activation Stratflix - Entrez votre code :", type=xbmcgui.INPUT_ALPHANUM)
        if not code: return False
    else:
        # Vérification silencieuse (le hash stocké sert de code)
        code = stored_hash

    try:
        payload = {'code': code, 'uuid': uuid}
        r = requests.post(LICENSE_SERVER_URL, data=payload, timeout=10)
        result = r.json()
        
        if result.get('status') == 'success':
            # On sauvegarde/met à jour les infos
            ADDON.setSetting('stratflix_license_hash', code)
            ADDON.setSetting('stratflix_date', datetime.now().strftime("%d/%m/%Y %H:%M"))
            return True
        else:
            xbmcgui.Dialog().ok("Erreur de Licence", "Code invalide ou déjà utilisé sur un autre appareil.")
            ADDON.setSetting('stratflix_license_hash', '') # Reset pour redemander
            return False
    except:
        xbmcgui.Dialog().notification("Erreur", "Serveur de licence injoignable", xbmcgui.NOTIFICATION_ERROR)
        return False

# --- Design & Vues ---
ART_BASE = {
    "main_films": "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1000",
    "main_series": "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?q=80&w=1000",
    "exclue": "https://i.imgur.com/eBf7pM8.png",
    "populaire": "https://i.imgur.com/5u8q3E0.png",
    "ancien": "https://i.imgur.com/9v4v9v4.png",
    "search": "https://i.imgur.com/8L8wz8m.png"
}

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'art', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

def add_item(name, action, url, thumb="", fanart="", is_folder=True, plot="", title_orig="", mode_type=""):
    li = xbmcgui.ListItem(label=name)
    if not fanart: fanart = os.path.join(ADDON_PATH, 'fanart.jpg')
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': fanart, 'landscape': fanart})
    
    info = li.getVideoInfoTag()
    if plot: info.setPlot(plot)
    info.setTitle(title_orig or name)
    
    params = {'action': action, 'url': url, 'mode_type': mode_type}
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

def set_view(view_id=54): 
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmc.executebuiltin(f"Container.SetViewMode({view_id})")

# --- Menus ---
def main_menu():
    add_item("🎬 FILMS", "genres_menu", "", thumb=get_art("films.png"), fanart=ART_BASE["main_films"], mode_type="movies")
    add_item("📺 SÉRIES", "genres_menu", "", thumb=get_art("series.png"), fanart=ART_BASE["main_series"], mode_type="series")
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu(mode_type):
    path_base = "film" if mode_type == "movies" else "serie"
    fanart_m = ART_BASE["main_films"] if mode_type == "movies" else ART_BASE["main_series"]
    
    add_item("[COLOR lightgreen]🔍 RECHERCHER[/COLOR]", "search", "", thumb=ART_BASE["search"], fanart=fanart_m)
    add_item("[COLOR red]🔥 EXCLUES[/COLOR]", "list_movies", f"{BASE_URL}/{path_base}-en-streaming/exclue/", thumb=ART_BASE["exclue"], fanart=fanart_m, mode_type=mode_type)
    add_item("[COLOR yellow]⭐ POPULAIRES[/COLOR]", "list_movies", f"{BASE_URL}/{path_base}-en-streaming/page/1/?filter_by=views", thumb=ART_BASE["populaire"], fanart=fanart_m, mode_type=mode_type)
    
    # ... boucle des genres ...
    xbmcplugin.endOfDirectory(HANDLE)
    set_view(54)

# --- ROUTER ---
if __name__ == '__main__':
    # On bloque tout si la licence n'est pas OK
    if not check_license():
        sys.exit()

    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')

    if not action or action == 'main':
        main_menu()
    elif action == 'genres_menu':
        genres_menu(params.get('mode_type', 'movies'))
    elif action == 'list_movies':
        # ... (le scraper list_movies habituel)
        pass
