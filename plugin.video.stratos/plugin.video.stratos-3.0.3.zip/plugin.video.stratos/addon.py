# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

def add_item(name, action, url, thumb="", is_folder=True, plot="", title_orig=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    
    # Configuration des infos pour le synopsis
    info = li.getVideoInfoTag()
    if plot: info.setPlot(plot)
    info.setTitle(title_orig or name)
    info.setMediaType('movie')

    q = urllib.parse.urlencode({'action': action, 'url': url, 'title': title_orig})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- SCRAPER PRINCIPAL ---
def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        r = requests.post(url, headers=headers, data=post_data, timeout=10) if post_data else requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(r.text, 'html.parser')
        
        # 1. RECUPERATION DES FILMS
        items = soup.find_all('div', class_='mov')
        for item in items:
            link_tag = item.find('a', class_='mov-t')
            if not link_tag: continue
            
            m_url = link_tag['href']
            m_title = link_tag.get_text(strip=True)
            
            # Image
            img_tag = item.find('img')
            m_thumb = ""
            if img_tag:
                src = img_tag.get('src', '')
                m_thumb = (BASE_URL + src) if src.startswith('/') else src
            
            # Synopsis
            m_plot = ""
            desc_divs = item.find_all('div', class_='ml-desc')
            if desc_divs: m_plot = desc_divs[-1].get_text(strip=True)

            # AJOUT DU FILM (is_folder=True car on va vers le choix des serveurs)
            add_item(m_title, 'select_source', m_url, thumb=m_thumb, plot=m_plot, title_orig=m_title)

        # 2. GESTION DE LA PAGE SUIVANTE
        nav = soup.find('div', class_='navigation')
        if nav:
            next_link = nav.find('a', string=re.compile(r'Suivant|Next|>', re.IGNORECASE))
            if next_link and next_link.get('href'):
                n_url = next_link['href']
                if not n_url.startswith('http'): n_url = BASE_URL + n_url
                add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", n_url, thumb=get_art("next.png"))

    except Exception as e:
        xbmc.log(f"STRATOS ERROR: {str(e)}", xbmc.LOGERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

# --- EXTRACTION DES LIENS (SERVEURS) ---
def select_source(url):
    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        # Signature loadVideo pour les liens officiels
        matches = re.findall(r"loadVideo\('([^']+)'\).*?<span>([^<]+)</span>", r, re.S)
        
        # Mapping des noms de serveurs
        srv_map = {'voe': 'VOE', 'vidmoly': 'VIDMOLY', 'uqload': 'UQLOAD', 'waaw': 'NETU'}

        for v_url, srv_name in matches:
            if v_url.startswith('//'): v_url = "https:" + v_url
            
            # On essaie d'avoir un nom propre
            clean_name = srv_name.strip().upper()
            
            li = xbmcgui.ListItem(label=f"▶ {clean_name}")
            li.setProperty('IsPlayable', 'true') # Indique que c'est un lien final
            
            q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
            
        xbmcplugin.endOfDirectory(HANDLE)
    except:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

# --- LECTURE ---
def play_video(url):
    try:
        import resolveurl
        resolved = resolveurl.resolve(url)
        if resolved:
            xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=resolved))
        else:
            xbmcgui.Dialog().notification("Erreur", "Lien non résolu")
    except:
        xbmcgui.Dialog().notification("Erreur", "ResolveURL manquant")

# --- ROUTER ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')

    if not action:
        # Menu Principal
        add_item("🎬 FILMS", "list_movies", f"{BASE_URL}/film-en-streaming/")
        add_item("📺 SÉRIES", "list_movies", f"{BASE_URL}/serie-en-streaming/")
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == 'list_movies':
        list_movies(params.get('url'))
    elif action == 'select_source':
        select_source(params.get('url'))
    elif action == 'play':
        play_video(params.get('url'))
