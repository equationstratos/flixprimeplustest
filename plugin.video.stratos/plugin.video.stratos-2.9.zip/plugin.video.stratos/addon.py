# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

# --- SERVEUR DE SÉCURITÉ ---
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    return os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)

# --- Sécurité & Activation ---
def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'): 
        return True
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        uuid = hashlib.sha256(raw_id.encode()).hexdigest()
        r = requests.post(URL_SERVEUR, data={'code': kb.upper().strip(), 'uuid': uuid}, timeout=10)
        resultat = r.json()
        if resultat.get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            xbmcgui.Dialog().ok("Activation Réussie", "Félicitations ! Votre accès est activé.\nProfitez bien de FlixPrimePlus.")
            return True
        else:
            xbmcgui.Dialog().ok("Échec", "Le code est invalide ou déjà utilisé sur un autre appareil.")
            return False
    except: return False

# --- Menus ---
def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]📺 SÉRIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]📂 GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [
        ("ACTION", "/film-en-streaming/action/", "action.png"), ("ANIMATION", "/film-en-streaming/animation/", "animation.png"),
        ("ARTS MARTIAUX", "/film-en-streaming/arts-martiaux/", "karate.png"), ("AVENTURE", "/film-en-streaming/aventure/", "adventure.png"),
        ("COMEDIE", "/film-en-streaming/comedie/", "comedy.png"), ("HORREUR", "/film-en-streaming/epouvante-horreur/", "horror.png"),
        ("DRAME", "/film-en-streaming/drame/", "drama.png"), ("SCIENCE FICTION", "/film-en-streaming/science-fiction/", "sci-fi.png"),
        ("THRILLER", "/film-en-streaming/thriller/", "thriller.png")
    ]
    for name, path, icon in genres:
        add_item(name, "list_movies", BASE_URL + path, thumb=get_art(icon))
    xbmcplugin.endOfDirectory(HANDLE)

# --- Scraping de Synopsis (Optimisé Page par Page) ---
def fetch_synopsis(movie_url):
    """Va chercher le synopsis directement sur la page du film"""
    try:
        if not movie_url.startswith('http'): movie_url = BASE_URL + movie_url
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=5)
        r.encoding = 'utf-8'
        soup = BeautifulSoup(r.text, 'html.parser')
        
        # Le synopsis est dans le bloc screenshots-full (vérifié sur ton code source)
        container = soup.find('div', class_='screenshots-full')
        if container:
            # On cherche le paragraphe qui contient le texte du synopsis
            paragraphs = container.find_all('p')
            for p in paragraphs:
                p_text = p.get_text(strip=True)
                if "Synopsis:" in p_text:
                    # On nettoie pour ne garder que l'histoire
                    # Retire "Synopsis:Résumé du film X en Streaming Complet:"
                    clean_text = re.sub(r'.*?Streaming Complet:', '', p_text, flags=re.IGNORECASE)
                    clean_text = clean_text.replace("Synopsis:", "").strip()
                    return clean_text

        # Secours via Meta Description (si le bloc précédent échoue)
        meta = soup.find('meta', {'name': 'description'})
        if meta: return meta.get('content', '').strip()
        
        return "Aucun résumé disponible."
    except: return ""

def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    add_item("[COLOR cyan]🏠 RETOUR AU MENU[/COLOR]", "main", "", thumb=get_art("home.png"))

    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        if post_data:
            r = requests.post(url, headers=headers, data=post_data, timeout=10)
        else:
            r = requests.get(url, headers=headers, timeout=10)
        
        r.encoding = 'utf-8'
        soup = BeautifulSoup(r.text, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        # Skip du slider si nécessaire (pour ne pas avoir de doublons)
        if not post_data and len(items) > 30: items = items[12:]

        movie_list = []
        for item in items:
            link_tag = item.find('a', class_='mov-t')
            if link_tag:
                title_span = link_tag.find('span', class_='title1')
                title = title_span.get_text(strip=True) if title_span else link_tag.get_text(strip=True)
                title = re.sub(r'(?i)flemmix|en streaming|vf|vostfr|HD', '', title).strip(' -:')
                
                img = item.find('img')
                thumb = ""
                if img:
                    src = img.get('src', '')
                    thumb = (BASE_URL + src) if src.startswith('/') else src
                
                m_url = link_tag['href']
                if not m_url.startswith('http'): m_url = BASE_URL + m_url
                movie_list.append({'title': title, 'url': m_url, 'thumb': thumb})

        # RECUPERATION EN PARALLELE (Indispensable car on doit ouvrir chaque page)
        with ThreadPoolExecutor(max_workers=10) as executor:
            synopses = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))

        for i, m in enumerate(movie_list):
            add_item(m['title'], 'select_source', m['url'], thumb=m['thumb'], plot=synopses[i], title_orig=m['title'])

        # Pagination
        nav = soup.find('div', class_='navigation')
        if nav:
            next_link = nav.find('a', string=re.compile(r'Suivant|Next|>', re.IGNORECASE))
            if next_link:
                n_url = next_link['href']
                if not n_url.startswith('http'): n_url = BASE_URL + n_url
                add_item("[COLOR green][B]➡ PAGE SUIVANTE[/B][/COLOR]", "list_movies", n_url, thumb=get_art("next.png"))
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", is_folder=True, plot="", title_orig=""):
    li = xbmcgui.ListItem(label=name)
    if not thumb: thumb = os.path.join(ADDON_PATH, 'icon.png')
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    
    # On force le plot pour Kodi (Double méthode pour compatibilité totale)
    if plot:
        li.setInfo('video', {'plot': plot, 'title': title_orig or name})
        video_tag = li.getVideoInfoTag()
        video_tag.setPlot(plot)
        video_tag.setTitle(title_orig or name)
        video_tag.setMediaType('movie')

    q = urllib.parse.urlencode({'action': action, 'url': url, 'title': title_orig, 'thumb': thumb})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

def select_source(url):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    srv_map = {'voe': 'VOE', 'uqload': 'UQLOAD', 'vidmoly': 'VIDMOLY', 'waaw': 'NETU', 'dsvplay': 'DDSTREAM'}
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        name = "SERVEUR EXTERNE"
        for key, val in srv_map.items():
            if key in v_url.lower(): name = val; break
        li = xbmcgui.ListItem(label=f"▶ {name}")
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Rechercher...')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", post_data=data)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    if verifier_licence():
        if not action or action == 'main': main_menu()
        elif action == 'genres_menu': genres_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'select_source': select_source(params.get('url'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else: xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
