# -*- coding: utf-8 -*-
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlencode, quote_plus

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = "https://flemmix.best"

# Utilisation d'une session pour garder les cookies (important pour certains sites de streaming)
session = requests.Session()

def get_html(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': BASE_URL
    }
    try:
        response = session.get(url, headers=headers, timeout=15)
        response.encoding = 'utf-8'
        return response.text
    except Exception as e:
        xbmcgui.Dialog().notification('Erreur Connexion', str(e))
        return None

def main_menu():
    categories = [
        ("Nouveautés", f"{BASE_URL}/"),
        ("Films", f"{BASE_URL}/film-en-streaming/"),
        ("Séries", f"{BASE_URL}/serie-en-streaming/"),
        ("Exclues", f"{BASE_URL}/film-en-streaming/exclue/"),
        ("Recherche", "search")
    ]
    for name, url in categories:
        if url == "search":
            add_directory_item(name, {"action": "search_menu"}, is_folder=True)
        else:
            add_directory_item(name, {"action": "list_content", "url": url}, is_folder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_content(url):
    html = get_html(url)
    if not html:
        return
    
    soup = BeautifulSoup(html, 'html.parser')
    
    # Tentative de capture plus large : on cherche les div 'mov' OU les 'item' du carousel
    items = soup.find_all('div', class_=re.compile(r'(mov|item)'))
    
    found = False
    for item in items:
        try:
            # Recherche du titre et du lien
            link_tag = item.find('a', href=True)
            if not link_tag or 'streaming' not in link_tag['href']:
                continue
                
            # Extraction du titre (cherche dans les spans ou l'attribut alt de l'image)
            title_tag = item.find('span', class_='title1') or item.find('a', class_='mov-t')
            img_tag = item.find('img')
            
            title = "Sans titre"
            if title_tag:
                title = title_tag.text.strip()
            elif img_tag and img_tag.get('alt'):
                title = img_tag['alt'].replace(' wiflix', '').replace(' flemmix', '')

            link = link_tag['href']
            if not link.startswith('http'):
                link = BASE_URL + link
            
            # Image
            img_url = ""
            if img_tag:
                img_url = img_tag.get('src', '')
                if img_url.startswith('/'):
                    img_url = BASE_URL + img_url

            # Qualité/Langue
            lang = item.find('span', class_='nbloc1').text if item.find('span', class_='nbloc1') else ""
            qual = item.find('span', class_='nbloc2').text if item.find('span', class_='nbloc2') else ""
            display_name = f"{title} ({lang} {qual})".strip()

            add_directory_item(display_name, {"action": "resolve_url", "url": link}, False, img_url)
            found = True
        except:
            continue

    if not found:
        xbmcgui.Dialog().ok("Info", "Aucun contenu trouvé. Le site a peut-être changé ses protections.")

    xbmcplugin.endOfDirectory(HANDLE)

def add_directory_item(name, params, is_folder, thumbnail=""):
    url = f"{sys.argv[0]}?{urlencode(params)}"
    list_item = xbmcgui.ListItem(label=name)
    if thumbnail:
        list_item.setArt({'thumb': thumbnail, 'poster': thumbnail})
    list_item.setInfo('video', {'title': name})
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

# ... (reste du code search et router identique au précédent)
