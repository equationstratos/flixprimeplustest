# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.rent"
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

# --- Customisation des Images ---
ART_BASE = {
    "main_films": "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1000",
    "main_series": "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?q=80&w=1000",
    "search": "https://i.imgur.com/8L8wz8m.png"
}

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'art', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

# --- Sécurité & Activation ---
def verifier_licence():
    stored_hash = ADDON.getSetting('stratflix_license_hash')
    raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
    uuid = hashlib.sha256(raw_id.encode()).hexdigest()

    if not stored_hash:
        kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
        if not kb: return False
        code_to_check = kb.upper().strip()
    else:
        code_to_check = stored_hash

    try:
        r = requests.post(URL_SERVEUR, data={'code': code_to_check, 'uuid': uuid}, timeout=10)
        resultat = r.json()
        if resultat.get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', code_to_check)
            ADDON.setSetting('stratflix_date', datetime.now().strftime("%d/%m/%Y %H:%M"))
            return True
        else:
            xbmcgui.Dialog().ok("Échec", "Le code est invalide ou déjà utilisé ailleurs.")
            ADDON.setSetting('stratflix_license_hash', '')
            return False
    except:
        if stored_hash: return True
        xbmcgui.Dialog().ok("Erreur", "Serveur d'activation injoignable.")
        return False

# --- UI Helpers ---
def add_item(name, action, url, thumb="", fanart="", is_folder=True, plot="", title_orig="", mode_type="", post_data=None):
    li = xbmcgui.ListItem(label=name)
    if not fanart: fanart = thumb if thumb else os.path.join(ADDON_PATH, 'fanart.jpg')
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': fanart})
    
    info = li.getVideoInfoTag()
    if plot: info.setPlot(plot)
    info.setTitle(title_orig or name)
    info.setMediaType('movie')
    
    params = {'action': action, 'url': url, 'title': title_orig, 'mode_type': mode_type}
    if post_data: params['post_data'] = urllib.parse.urlencode(post_data)
    
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

def set_view(view_id=54):
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmc.executebuiltin(f"Container.SetViewMode({view_id})")

# --- Scrapers ---
def fetch_synopsis(movie_url):
    try:
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=5)
        soup = BeautifulSoup(r.text, 'html.parser')
        desc_block = soup.find('div', class_='movie-text')
        if desc_block:
            lines = desc_block.find_all('div', class_='ml-desc')
            if lines: return lines[-1].get_text(strip=True)
        return "Aucun synopsis."
    except: return ""

def list_movies(url, mode_type="movies", post_data=None):
    add_item("[COLOR cyan]🏠 ACCUEIL[/COLOR]", "main", "", thumb=get_art("home.png"))
    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        r = requests.post(url, headers=headers, data=post_data, timeout=10) if post_data else requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(r.text, 'html.parser')
        items = soup.find_all('div', class_='mov')
        
        movie_results = []
        for item in items:
            link = item.find('a', class_='mov-t')
            if not link: continue
            title = link.find('span', class_='title1').text if link.find('span', class_='title1') else link.text
            img = item.find('img')
            thumb = (BASE_URL + img['src']) if img and img['src'].startswith('/') else img.get('src', '')
            movie_results.append({'title': title, 'url': link['href'], 'thumb': thumb})

        with ThreadPoolExecutor(max_workers=10) as executor:
            plots = list(executor.map(fetch_synopsis, [m['url'] for m in movie_results]))

        for i, m in enumerate(movie_results):
            add_item(m['title'], 'select_source', m['url'], thumb=m['thumb'], fanart=m['thumb'], plot=plots[i])

        # Pagination
        nav = soup.find('div', class_='navigation')
        if nav:
            next_link = nav.find('a', string=re.compile(r'Suivant|>', re.IGNORECASE))
            if next_link:
                add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", next_link['href'], thumb=get_art("next.png"), mode_type=mode_type)

        xbmcplugin.endOfDirectory(HANDLE)
        set_view(54)
    except: xbmcplugin.endOfDirectory(HANDLE, False)

def select_source(url):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    srv_map = {'voe': 'VOE', 'uqload': 'UQLOAD', 'vidmoly': 'VIDMOLY', 'waaw': 'NETU'}
    
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        name = "SERVEUR"
        for key, val in srv_map.items():
            if key in v_url.lower(): name = val; break
        li = xbmcgui.ListItem(label=f"▶ {name}")
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmcgui.Dialog().input("Recherche...", type=xbmcgui.INPUT_ALPHANUM)
    if kb:
        data = {'do': 'search', 'subaction': 'search', 'story': kb}
        list_movies(f"{BASE_URL}/index.php?do=search", post_data=data)

# --- Menus ---
def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "", thumb=ART_BASE["search"])
    add_item("🎬 FILMS", "genres_menu", "", thumb=get_art("films.png"), fanart=ART_BASE["main_films"], mode_type="movies")
    add_item("📺 SÉRIES", "genres_menu", "", thumb=get_art("series.png"), fanart=ART_BASE["main_series"], mode_type="series")
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu(mode_type):
    base = "film" if mode_type == "movies" else "serie"
    genres = [("Action", "action"), ("Animation", "animation"), ("Aventure", "aventure"), ("Horreur", "epouvante-horreur")]
    for name, slug in genres:
        add_item(name, "list_movies", f"{BASE_URL}/{base}-en-streaming/{slug}/", mode_type=mode_type)
    xbmcplugin.endOfDirectory(HANDLE)
    set_view(54)

# --- Router ---
if __name__ == '__main__':
    if verifier_licence():
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        act = params.get('action')
        if not act or act == 'main': main_menu()
        elif act == 'genres_menu': genres_menu(params.get('mode_type'))
        elif act == 'list_movies': list_movies(params.get('url'), mode_type=params.get('mode_type'))
        elif act == 'search': search()
        elif act == 'select_source': select_source(params.get('url'))
        elif act == 'play': play_video(params.get('url'))
    else: sys.exit()
