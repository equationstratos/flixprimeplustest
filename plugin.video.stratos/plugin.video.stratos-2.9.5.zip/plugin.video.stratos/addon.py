# -*- coding: utf-8 -*-
import sys
import urllib.parse
import requests
import re
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon

# --- Configuration ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

def list_movies(url):
    xbmcplugin.setContent(HANDLE, 'movies')
    
    try:
        # 1. Récupération de la page
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10)
        r.encoding = 'utf-8'
        html = r.text

        # 2. On isole la partie "dle-content" pour éviter les faux positifs (menus, etc.)
        content_zone = re.findall(r"<div id='dle-content'>(.*?)<div class=\"bottom-nav\"", html, re.DOTALL)
        if not content_zone:
            content_zone = [html] # Fallback si la zone n'est pas trouvée

        # 3. Scraping des films avec le nouveau format 2026
        # On cherche l'image, le lien, le titre et le synopsis d'un coup
        pattern = (
            r'class="mov clearfix".*?'         # Début du bloc
            r'img src="(?P<thumb>.*?)".*?'     # Image
            r'href="(?P<url>.*?)">(?P<title>.*?)</a>.*?' # URL et Titre
            r'Synopsis:</div> <div class="ml-desc">(?P<plot>.*?)</div>' # Synopsis
        )
        
        matches = re.finditer(pattern, content_zone[0], re.DOTALL)
        
        count = 0
        for m in matches:
            count += 1
            title = m.group('title').strip()
            m_url = m.group('url')
            thumb = m.group('thumb')
            plot = m.group('plot').strip()

            # Nettoyage des URLs
            if not m_url.startswith('http'): m_url = BASE_URL + m_url
            if not thumb.startswith('http'): thumb = BASE_URL + thumb
            
            # Nettoyage du synopsis (enlève les espaces en trop)
            plot = re.sub(r'\s+', ' ', plot)

            add_item(title, 'select_source', m_url, thumb=thumb, plot=plot)

        # 4. Gestion de la pagination (Suivant)
        next_page = re.findall(r'<a href="([^"]+)"><span>Suivant</span>', html)
        if next_page:
            add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", next_page[0])

        if count == 0:
            xbmcgui.Dialog().ok("Info", "Aucun film trouvé. Le site a peut-être changé ses balises.")

    except Exception as e:
        xbmc.log(f"Erreur Flemmix: {str(e)}", xbmc.LOGERROR)

    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", plot=""):
    li = xbmcgui.ListItem(label=name)
    if not thumb: thumb = ADDON.getAddonInfo('icon')
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    
    # Injection du synopsis
    if plot:
        li.setInfo('video', {'title': name, 'plot': plot, 'plotoutline': plot})
        # Pour les versions récentes de Kodi (Nexus/Omega)
        try:
            info = li.getVideoInfoTag()
            info.setTitle(name)
            info.setPlot(plot)
        except: pass

    u = f"{sys.argv[0]}?action={action}&url={urllib.parse.quote_plus(url)}"
    xbmcplugin.addDirectoryItem(HANDLE, u, li, True)

# --- Point d'entrée ---
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
action = params.get('action')
url = params.get('url')

if not action:
    # Menu principal simplifié pour le test
    add_item("🎬 FILMS", "list_movies", f"{BASE_URL}/film-en-streaming/")
    xbmcplugin.endOfDirectory(HANDLE)
elif action == 'list_movies':
    list_movies(url)
