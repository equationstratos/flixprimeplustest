# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
import json
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    return os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)

# --- Sécurité & Activation ---
def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'): 
        return True
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        uuid = hashlib.sha256(raw_id.encode()).hexdigest()
        r = requests.post(URL_SERVEUR, data={'code': kb.upper().strip(), 'uuid': uuid}, timeout=10)
        if r.json().get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            return True
    except: pass
    return False

# --- Menus ---
def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]📺 SÉRIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]📂 GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [("ACTION", "/film-en-streaming/action/", "action.png"), ("HORREUR", "/film-en-streaming/epouvante-horreur/", "horror.png"), ("SF", "/film-en-streaming/science-fiction/", "sci-fi.png")]
    for name, path, icon in genres:
        add_item(name, "list_movies", BASE_URL + path, thumb=get_art(icon))
    xbmcplugin.endOfDirectory(HANDLE)

def add_item(name, action, url, thumb="", is_folder=True, plot="", title_orig=""):
    li = xbmcgui.ListItem(label=name)
    if not thumb: thumb = os.path.join(ADDON_PATH, 'icon.png')
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    if plot:
        info = li.getVideoInfoTag()
        info.setPlot(plot)
    q = urllib.parse.urlencode({'action': action, 'url': url, 'title': title_orig})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- Scraping Agnostique (Indépendant des balises) ---
def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    try:
        headers = {'User-Agent': USER_AGENT}
        if post_data:
            r = requests.post(url, headers=headers, data=post_data, timeout=10).text
        else:
            r = requests.get(url, headers=headers, timeout=10).text

        # RECHERCHE PAR SIGNATURE D'URL (Ignore le HTML sale)
        # Trouve le lien, l'ID et le SLUG (nom dans l'url)
        pattern = r'href="(https?://flemmix\.[a-z]+/film-en-streaming/(\d+)-([^"]+)\.html)"'
        matches = re.findall(pattern, r)
        
        # Image par signature (cherche les images liées aux IDs de films)
        img_pattern = r'src="([^"]+)" alt="([^"]+)"'
        images = dict(re.findall(r'alt="([^"]+)".*?src="([^"]+)"', r))

        seen = set()
        for full_url, m_id, slug in matches:
            if full_url in seen: continue
            seen.add(full_url)
            
            # Titre propre généré depuis l'URL (increvable)
            clean_title = slug.replace('-', ' ').upper()
            
            # Recherche de l'image correspondante
            thumb = ""
            for alt_text, img_url in images.items():
                if slug[:5].lower() in alt_text.lower(): # Match partiel du nom
                    thumb = BASE_URL + img_url if img_url.startswith('/') else img_url
                    break

            add_item(clean_title, 'select_source', full_url, thumb=thumb)

        # Pagination simple
        match_page = re.search(r'/page/(\d+)', url)
        curr = int(match_page.group(1)) if match_page else 1
        next_url = url.replace(f'/page/{curr}', f'/page/{curr+1}') if match_page else url.rstrip('/') + f'/page/{curr+1}/'
        add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", next_url, thumb=get_art("next.png"))

    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def select_source(url):
    """Extraction des serveurs par signature JS loadVideo"""
    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        # Trouve loadVideo('LIEN') et le <span> qui contient le nom du serveur
        matches = re.findall(r"loadVideo\('([^']+)'\).*?<span>([^<]+)</span>", r, re.S)
        
        if not matches:
            # Plan B: recherche brute des hébergeurs connus
            brut = re.findall(r'(https?://(?:voe|vidmoly|uqload|waaw|luluvdo)\.[a-z0-9/.]+)', r)
            matches = [(u, "Serveur Direct") for u in brut]

        for v_url, name in matches:
            if v_url.startswith('//'): v_url = "https:" + v_url
            li = xbmcgui.ListItem(label=f"▶ {name.strip().upper()}")
            li.setProperty('IsPlayable', 'true')
            q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        hmf = resolveurl.resolve(url)
        if hmf:
            xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=hmf))
    except:
        xbmcgui.Dialog().notification("Erreur", "Lien non supporté", xbmcgui.NOTIFICATION_ERROR)

def search():
    kb = xbmc.Keyboard('', 'Rechercher...')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", post_data=data)

# --- Router ---
if __name__ == '__main__':
    if verifier_licence():
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        action = params.get('action')
        if not action or action == 'main': main_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'select_source': select_source(params.get('url'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
        elif action == 'genres_menu': genres_menu()
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
