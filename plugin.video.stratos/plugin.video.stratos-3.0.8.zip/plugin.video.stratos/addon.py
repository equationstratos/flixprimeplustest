# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

# --- Customisation des Images (Modifiables) ---
# Tu peux remplacer ces URLs par tes propres images ou par get_art("nom.png")
ART_BASE = {
    "main_films": "https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1000", # Fanart Films
    "main_series": "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?q=80&w=1000", # Fanart Séries
    "exclue": "https://i.imgur.com/eBf7pM8.png",
    "populaire": "https://i.imgur.com/5u8q3E0.png",
    "ancien": "https://i.imgur.com/9v4v9v4.png",
    "search": "https://i.imgur.com/8L8wz8m.png"
}

GENRES = [
    ("Action", "action"), ("Animation", "animation"), ("Arts Martiaux", "arts-martiaux"),
    ("Aventure", "aventure"), ("Biopic", "biopic"), ("Comédie", "comedie"),
    ("Comédie Dramatique", "comedie-dramatique"), ("Epouvante Horreur", "epouvante-horreur"),
    ("Drame", "drame"), ("Documentaire", "documentaire"), ("Espionnage", "espionnage"),
    ("Famille", "famille"), ("Fantastique", "fantastique"), ("Guerre", "guerre"),
    ("Historique", "historique"), ("Musical", "musical"), ("Policier", "policier"),
    ("Romance", "romance"), ("Science Fiction", "science-fiction"), ("Spectacles", "spectacles"),
    ("Thriller", "thriller"), ("Western", "western")
]

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'art', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

def add_item(name, action, url, thumb="", fanart="", is_folder=True, plot="", title_orig="", mode_type="", post_data=None):
    li = xbmcgui.ListItem(label=name)
    
    # Utilisation d'un fanart par défaut si vide
    if not fanart: fanart = os.path.join(ADDON_PATH, 'fanart.jpg')
    
    li.setArt({
        'thumb': thumb, 
        'icon': thumb,
        'poster': thumb, 
        'fanart': fanart,
        'landscape': fanart
    })
    
    info = li.getVideoInfoTag()
    if plot: info.setPlot(plot)
    info.setTitle(title_orig or name)
    info.setMediaType('movie')
    
    params = {'action': action, 'url': url, 'title': title_orig, 'mode_type': mode_type}
    if post_data: params['post_data'] = urllib.parse.urlencode(post_data)
    
    q = urllib.parse.urlencode(params)
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- NAVIGATION & VUES ---
def set_view(view_id=504): # 504 = InfoWall sur Estuary
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmc.executebuiltin(f"Container.SetViewMode({view_id})")

def search_movie():
    search_query = xbmcgui.Dialog().input("Rechercher sur Flemmix...", type=xbmcgui.INPUT_ALPHANUM)
    if search_query:
        search_url = f"{BASE_URL}/index.php?do=search"
        post_data = {'do': 'search', 'subaction': 'search', 'search_start': '0', 'full_search': '0', 'result_from': '1', 'story': search_query}
        list_movies(search_url, post_data=post_data)

# --- MENUS ---
def genres_menu(mode_type):
    path_base = "film" if mode_type == "movies" else "serie"
    fanart_menu = ART_BASE["main_films"] if mode_type == "movies" else ART_BASE["main_series"]

    add_item("[COLOR lightgreen]🔍 RECHERCHER[/COLOR]", "search", "", thumb=ART_BASE["search"], fanart=fanart_menu)
    add_item("[COLOR red]🔥 EXCLUES[/COLOR]", "list_movies", f"{BASE_URL}/{path_base}-en-streaming/exclue/", thumb=ART_BASE["exclue"], fanart=fanart_menu, mode_type=mode_type)
    add_item("[COLOR yellow]⭐ POPULAIRES[/COLOR]", "list_movies", f"{BASE_URL}/{path_base}-en-streaming/page/1/?filter_by=views", thumb=ART_BASE["populaire"], fanart=fanart_menu, mode_type=mode_type)
    add_item("[COLOR orange]📅 ANCIENS[/COLOR]", "list_movies", f"{BASE_URL}/film-ancien/", thumb=ART_BASE["ancien"], fanart=fanart_menu, mode_type=mode_type)
    
    for name, slug in GENRES:
        url = f"{BASE_URL}/{path_base}-en-streaming/{slug}/"
        # On cherche une icône locale genre "action.png", sinon icône par défaut
        icon = get_art(f"{slug}.png")
        add_item(name, "list_movies", url, thumb=icon, fanart=fanart_menu, mode_type=mode_type)
    
    xbmcplugin.endOfDirectory(HANDLE)
    set_view(504)

def list_movies(url, mode_type="movies", post_data=None):
    add_item("[COLOR red]⬅ RETOUR AU MENU[/COLOR]", "main", "", thumb=get_art("back.png"))
    if not post_data:
        add_item("[COLOR lightblue]🔢 ALLER À LA PAGE...[/COLOR]", "go_to_page", url, thumb=get_art("page.png"))

    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        r = requests.post(url, headers=headers, data=post_data, timeout=10) if post_data else requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(r.text, 'html.parser')
        
        items = soup.find_all('div', class_='mov')
        for item in items:
            link_tag = item.find('a', class_='mov-t')
            if not link_tag: continue
            m_url = link_tag['href']
            m_title = link_tag.get_text(strip=True)
            img_tag = item.find('img')
            m_thumb = (BASE_URL + img_tag['src']) if img_tag and img_tag['src'].startswith('/') else img_tag.get('src', '')
            desc_divs = item.find_all('div', class_='ml-desc')
            m_plot = desc_divs[-1].get_text(strip=True) if desc_divs else ""

            # On utilise l'affiche du film aussi comme fanart pour l'effet InfoWall
            add_item(m_title, 'select_source', m_url, thumb=m_thumb, fanart=m_thumb, plot=m_plot, title_orig=m_title)

        if items and not post_data:
            match = re.search(r'/page/(\d+)', url)
            n_url = url.replace(f'/page/{match.group(1)}', f'/page/{int(match.group(1))+1}') if match else (url.replace('?', 'page/2/?') if '?' in url else url.rstrip('/') + "/page/2/")
            add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", n_url, thumb=get_art("next.png"))

    except: pass
    xbmcplugin.endOfDirectory(HANDLE)
    set_view(504) # Applique la vue InfoWall

# --- (Reste du code: select_source, play_video, router identique) ---

def select_source(url):
    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        matches = re.findall(r"loadVideo\('([^']+)'\).*?<span>([^<]+)</span>", r, re.S)
        for v_url, srv_name in matches:
            if v_url.startswith('//'): v_url = "https:" + v_url
            li = xbmcgui.ListItem(label=f"▶ {srv_name.strip().upper()}")
            li.setProperty('IsPlayable', 'true')
            q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
        xbmcplugin.endOfDirectory(HANDLE)
    except: xbmcplugin.endOfDirectory(HANDLE, False)

def play_video(url):
    try:
        import resolveurl
        resolved = resolveurl.resolve(url)
        if resolved: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=resolved))
    except: pass

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    m_type = params.get('mode_type', 'movies')
    p_data = dict(urllib.parse.parse_qsl(params.get('post_data'))) if params.get('post_data') else None

    if not action or action == 'main':
        add_item("🎬 FILMS", "genres_menu", "", thumb=get_art("films.png"), fanart=ART_BASE["main_films"], mode_type="movies")
        add_item("📺 SÉRIES", "genres_menu", "", thumb=get_art("series.png"), fanart=ART_BASE["main_series"], mode_type="series")
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == 'genres_menu':
        genres_menu(m_type)
    elif action == 'search':
        search_movie()
    elif action == 'list_movies':
        list_movies(params.get('url'), mode_type=m_type, post_data=p_data)
    elif action == 'go_to_page':
        from go_to_page_module import go_to_page # Simulation ou intégration directe
        # Note: Reprendre la fonction go_to_page précédente
    elif action == 'select_source':
        select_source(params.get('url'))
    elif action == 'play':
        play_video(params.get('url'))
