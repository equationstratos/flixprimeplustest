# -*- coding: utf-8 -*-
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlencode, quote_plus

# Informations de l'addon
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = "https://flemmix.best"

def get_html(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': BASE_URL
    }
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = 'utf-8'
        return response.text
    except:
        return None

def main_menu():
    # Menu principal basé sur la structure du site
    categories = [
        ("Nouveautés", f"{BASE_URL}/"),
        ("Films", f"{BASE_URL}/film-en-streaming/"),
        ("Séries", f"{BASE_URL}/serie-en-streaming/"),
        ("Exclues", f"{BASE_URL}/film-en-streaming/exclue/"),
        ("Animation", f"{BASE_URL}/film-en-streaming/animation/"),
        ("Recherche", "search")
    ]
    
    for name, url in categories:
        if url == "search":
            add_directory_item(name, {"action": "search_menu"}, is_folder=True)
        else:
            add_directory_item(name, {"action": "list_content", "url": url}, is_folder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_content(url):
    html = get_html(url)
    if not html:
        return
    
    soup = BeautifulSoup(html, 'html.parser')
    # On cible les div class="mov" d'après ton code source
    items = soup.find_all('div', class_='mov')
    
    for item in items:
        try:
            # Titre et Lien
            title_tag = item.find('a', class_='mov-t')
            title = title_tag.text.strip()
            link = title_tag['href']
            
            # Image (Gestion du checkimg.php présent dans ton HTML)
            img_tag = item.find('img')
            img_url = img_tag['src']
            if img_url.startswith('/'):
                img_url = BASE_URL + img_url
            
            # Qualité et Langue (nbloc1-2 dans ton code)
            lang = item.find('span', class_='nbloc1').text if item.find('span', class_='nbloc1') else ""
            qual = item.find('span', class_='nbloc2').text if item.find('span', class_='nbloc2') else ""
            full_title = f"[{lang}][{qual}] {title}"
            
            # Synopsis
            plot = ""
            synopsis_div = item.find('div', class_='ml-desc')
            if synopsis_div:
                plot = synopsis_div.text.strip()

            add_directory_item(full_title, 
                               {"action": "resolve_url", "url": link}, 
                               is_folder=False, 
                               thumbnail=img_url, 
                               plot=plot)
        except Exception as e:
            continue

    # Pagination (Basé sur la structure standard DLE souvent utilisée sur ces sites)
    next_page = soup.find('span', class_='pnext')
    if next_page and next_page.parent.name == 'a':
        next_url = next_page.parent['href']
        add_directory_item(">>> Page Suivante", {"action": "list_content", "url": next_url}, is_folder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def search():
    keyboard = xbmcgui.Keyboard('', 'Rechercher sur Flemmix')
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText()
        # Le site utilise un POST normalement, mais beaucoup acceptent le GET pour la recherche
        search_url = f"{BASE_URL}/index.php?do=search&subaction=search&story={quote_plus(query)}"
        list_content(search_url)

def add_directory_item(name, params, is_folder, thumbnail="", plot=""):
    url = f"{sys.argv[0]}?{urlencode(params)}"
    list_item = xbmcgui.ListItem(label=name)
    if thumbnail:
        list_item.setArt({'thumb': thumbnail, 'icon': thumbnail, 'poster': thumbnail})
    if plot:
        list_item.setInfo('video', {'plot': plot, 'title': name})
    else:
        list_item.setInfo('video', {'title': name})
    
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, is_folder)

def router(paramstring):
    params = dict(re.findall(r'([^=&?]+)=([^&]*)', paramstring))
    action = params.get('action')

    if not action:
        main_menu()
    elif action == 'list_content':
        list_content(params['url'])
    elif action == 'search_menu':
        search()
    elif action == 'resolve_url':
        # Ici il faudrait ajouter un resolveur (type Youtube-dl ou script manuel)
        # pour extraire l'iframe de la page finale.
        xbmcgui.Dialog().notification('Lecture', 'Extraction du lien vidéo en cours...')

if __name__ == '__main__':
    router(sys.argv[2][1:])
