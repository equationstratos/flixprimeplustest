# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

def get_art(filename):
    path = os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)
    return path if os.path.exists(path) else os.path.join(ADDON_PATH, 'icon.png')

def add_item(name, action, url, thumb="", is_folder=True, plot="", title_orig=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    
    # Configuration des métadonnées (Synopsis et Titre)
    info = li.getVideoInfoTag()
    if plot: info.setPlot(plot)
    info.setTitle(title_orig or name)
    info.setMediaType('movie')

    q = urllib.parse.urlencode({'action': action, 'url': url, 'title': title_orig})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- SCRAPER PRINCIPAL ---
def list_movies(url, post_data=None):
    # On force la vue en mode "Films" pour afficher les affiches proprement
    xbmcplugin.setContent(HANDLE, 'movies')
    
    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        r = requests.post(url, headers=headers, data=post_data, timeout=10) if post_data else requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(r.text, 'html.parser')
        
        # 1. RÉCUPÉRATION DES ITEMS (FILMS/SÉRIES)
        items = soup.find_all('div', class_='mov')
        for item in items:
            link_tag = item.find('a', class_='mov-t')
            if not link_tag: continue
            
            m_url = link_tag['href']
            m_title = link_tag.get_text(strip=True)
            
            # Extraction de l'image
            img_tag = item.find('img')
            m_thumb = ""
            if img_tag:
                src = img_tag.get('src', '')
                m_thumb = (BASE_URL + src) if src.startswith('/') else src
            
            # Extraction du synopsis (souvent dans le dernier ml-desc)
            m_plot = ""
            desc_divs = item.find_all('div', class_='ml-desc')
            if desc_divs: 
                m_plot = desc_divs[-1].get_text(strip=True)

            add_item(m_title, 'select_source', m_url, thumb=m_thumb, plot=m_plot, title_orig=m_title)

        # 2. PAGINATION CALCULÉE (Basée sur l'URL)
        # On évite de chercher les balises HTML, on incrémente juste le chiffre
        if items: # Si la page n'est pas vide
            match = re.search(r'/page/(\d+)', url)
            if match:
                current_page = int(match.group(1))
                next_page = current_page + 1
                n_url = url.replace(f'/page/{current_page}', f'/page/{next_page}')
            else:
                # On est en page 1, on ajoute le suffixe de page
                base = url.rstrip('/')
                n_url = f"{base}/page/2/"
            
            add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", n_url, thumb=get_art("next.png"))

    except Exception as e:
        xbmc.log(f"STRATOS ERROR: {str(e)}", xbmc.LOGERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

# --- CHOIX DU SERVEUR ---
def select_source(url):
    try:
        r = requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10).text
        # Détection des liens via la signature loadVideo du site
        matches = re.findall(r"loadVideo\('([^']+)'\).*?<span>([^<]+)</span>", r, re.S)
        
        if not matches:
            # Plan B: détection brute des liens d'hébergeurs
            brut = re.findall(r'(https?://(?:voe|vidmoly|uqload|waaw|luluvdo)\.[a-z0-9/.]+)', r)
            matches = [(u, "Serveur Direct") for u in brut]

        for v_url, srv_name in matches:
            if v_url.startswith('//'): v_url = "https:" + v_url
            
            li = xbmcgui.ListItem(label=f"▶ {srv_name.strip().upper()}")
            li.setProperty('IsPlayable', 'true')
            
            q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
            
        xbmcplugin.endOfDirectory(HANDLE)
    except:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

# --- LECTURE ---
def play_video(url):
    try:
        import resolveurl
        resolved = resolveurl.resolve(url)
        if resolved:
            xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=resolved))
        else:
            xbmcgui.Dialog().notification("Erreur", "Lien non supporté par ResolveURL")
    except:
        xbmcgui.Dialog().notification("Erreur", "Module ResolveURL introuvable")

# --- ROUTER ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')

    if not action:
        # Menu d'accueil
        add_item("🎬 FILMS", "list_movies", f"{BASE_URL}/film-en-streaming/")
        add_item("📺 SÉRIES", "list_movies", f"{BASE_URL}/serie-en-streaming/")
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == 'list_movies':
        list_movies(params.get('url'))
    elif action == 'select_source':
        select_source(params.get('url'))
    elif action == 'play':
        play_video(params.get('url'))
