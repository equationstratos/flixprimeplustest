# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import requests
import re
import hashlib
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
from concurrent.futures import ThreadPoolExecutor

# --- Configuration ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = "https://flemmix.best"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

# --- SERVEUR DE SÉCURITÉ ---
URL_SERVEUR = "http://192.168.1.107/flixprimeplus/check.php"

def get_art(filename):
    return os.path.join(ADDON_PATH, 'resources', 'icones-menus', filename)

# --- Sécurité & Activation ---
def verifier_licence():
    if ADDON.getSetting('stratflix_license_hash'): return True
    kb = xbmcgui.Dialog().input("Activation FlixPrimePlus", type=xbmcgui.INPUT_ALPHANUM)
    if not kb: return False
    try:
        raw_id = xbmc.getInfoLabel('System.FriendlyName') + xbmc.getInfoLabel('System.KernelVersion')
        uuid = hashlib.sha256(raw_id.encode()).hexdigest()
        r = requests.post(URL_SERVEUR, data={'code': kb.upper().strip(), 'uuid': uuid}, timeout=10)
        if r.json().get('status') == "success":
            ADDON.setSetting('stratflix_license_hash', kb.upper().strip())
            xbmcgui.Dialog().ok("Activation Réussie", "Félicitations ! Votre accès est activé.\nProfitez bien de FlixPrimePlus.")
            return True
    except: pass
    return False

# --- Menus ---
def main_menu():
    add_item("[COLOR yellow]🔍 RECHERCHE[/COLOR]", "search", "", thumb=get_art("search.png"))
    add_item("[COLOR white]🎬 FILMS[/COLOR]", "list_movies", f"{BASE_URL}/film-en-streaming/", thumb=get_art("movies.png"))
    add_item("[COLOR lightblue]📺 SÉRIES[/COLOR]", "list_movies", f"{BASE_URL}/serie-en-streaming/", thumb=get_art("series.png"))
    add_item("[COLOR orange]📂 GENRES[/COLOR]", "genres_menu", "", thumb=get_art("genres.png"))
    xbmcplugin.endOfDirectory(HANDLE)

def genres_menu():
    genres = [("ACTION", "/film-en-streaming/action/", "action.png"), ("DRAME", "/film-en-streaming/drame/", "drama.png"), ("SCI-FI", "/film-en-streaming/science-fiction/", "sci-fi.png")]
    for name, path, icon in genres:
        add_item(name, "list_movies", BASE_URL + path, thumb=get_art(icon))
    xbmcplugin.endOfDirectory(HANDLE)

# --- SCRAPER SYNOPSIS (Page par page) ---
def fetch_synopsis(movie_url):
    try:
        r = requests.get(movie_url, headers={'User-Agent': USER_AGENT}, timeout=4)
        r.encoding = 'utf-8'
        soup = BeautifulSoup(r.text, 'html.parser')
        
        # Ciblage du paragraphe spécifique (Structure 2026)
        syn_h3 = soup.find('h3', class_='synop')
        if syn_h3:
            p_text = syn_h3.parent.get_text(strip=True)
            # Nettoyage
            res = p_text.split("Complet:")[1] if "Complet:" in p_text else p_text
            return res.replace("Synopsis:", "").strip()
            
        # Secours : Meta description
        meta = soup.find('meta', {'name': 'description'})
        if meta: return meta.get('content', '').strip()
    except: pass
    return "Synopsis en cours de mise à jour..."

# --- LISTAGE FILMS & PAGINATION ---
def list_movies(url, post_data=None):
    xbmcplugin.setContent(HANDLE, 'movies')
    # Option Aller à la page
    add_item("[COLOR yellow]🔢 ALLER À LA PAGE...[/COLOR]", "go_to_page", url, thumb=get_art("pages.png"))

    try:
        r = requests.post(url, data=post_data, headers={'User-Agent': USER_AGENT}, timeout=10) if post_data else requests.get(url, headers={'User-Agent': USER_AGENT}, timeout=10)
        r.encoding = 'utf-8'
        soup = BeautifulSoup(r.text, 'html.parser')
        
        items = soup.find_all('div', class_='mov')
        movie_list = []
        for item in items:
            t_tag = item.find('a', class_='mov-t')
            if not t_tag: continue
            
            title = t_tag.get_text(strip=True)
            m_url = t_tag['href'] if t_tag['href'].startswith('http') else BASE_URL + t_tag['href']
            
            img = item.find('img')
            thumb = img['src'] if img else ""
            if thumb.startswith('/'): thumb = BASE_URL + thumb
            
            movie_list.append({'title': title, 'url': m_url, 'thumb': thumb})

        # Récupération parallèle des synopsis
        with ThreadPoolExecutor(max_workers=8) as executor:
            plots = list(executor.map(fetch_synopsis, [m['url'] for m in movie_list]))

        for i, m in enumerate(movie_list):
            add_item(m['title'], 'select_source', m['url'], thumb=m['thumb'], plot=plots[i])

        # PAGINATION CORRIGÉE
        nav = soup.find('div', class_='navigation')
        if nav:
            # On cherche le bouton "Suivant"
            next_btn = nav.find('a', string=re.compile(r'Suivant|Next|>', re.IGNORECASE))
            if next_btn:
                n_url = next_btn['href'] if next_btn['href'].startswith('http') else BASE_URL + next_btn['href']
                add_item("[COLOR green]➡ PAGE SUIVANTE[/COLOR]", "list_movies", n_url, thumb=get_art("next.png"))
                
    except Exception as e:
        xbmc.log(f"ERREUR FLIX: {str(e)}", xbmc.LOGERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

def go_to_page(base_url):
    kb = xbmcgui.Dialog().input("Numéro de la page", type=xbmcgui.INPUT_NUMBER)
    if kb:
        # Flemmix utilise souvent /page/X/ dans l'URL
        new_url = base_url.rstrip('/') + f"/page/{kb}/"
        list_movies(new_url)

def add_item(name, action, url, thumb="", is_folder=True, plot=""):
    li = xbmcgui.ListItem(label=name)
    if not thumb: thumb = os.path.join(ADDON_PATH, 'icon.png')
    li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
    
    if plot:
        # On remplit toutes les infos possibles pour forcer l'affichage
        li.setInfo('video', {'plot': plot, 'title': name, 'plotoutline': plot})
        try:
            video_tag = li.getVideoInfoTag()
            video_tag.setPlot(plot)
            video_tag.setTitle(name)
        except: pass

    q = urllib.parse.urlencode({'action': action, 'url': url})
    xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, is_folder)

# --- SOURCES & LECTURE ---
def select_source(url):
    r = requests.get(url, headers={'User-Agent': USER_AGENT}).text
    matches = re.findall(r"loadVideo\('(.+?)'\)", r)
    for v_url in set(matches):
        v_url = "https:" + v_url if v_url.startswith('//') else v_url
        name = "SERVEUR"
        if 'voe' in v_url: name = "VOE"
        elif 'uqload' in v_url: name = "UQLOAD"
        li = xbmcgui.ListItem(label=f"▶ {name}")
        li.setProperty('IsPlayable', 'true')
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmc.Keyboard('', 'Rechercher...')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        data = {'do': 'search', 'subaction': 'search', 'story': kb.getText()}
        list_movies(f"{BASE_URL}/index.php?do=search", post_data=data)

# --- Router ---
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action')
    if verifier_licence():
        if not action or action == 'main': main_menu()
        elif action == 'genres_menu': genres_menu()
        elif action == 'list_movies': list_movies(params.get('url'))
        elif action == 'go_to_page': go_to_page(params.get('url'))
        elif action == 'select_source': select_source(params.get('url'))
        elif action == 'play': play_video(params.get('url'))
        elif action == 'search': search()
    else: xbmcplugin.endOfDirectory(HANDLE, False)
